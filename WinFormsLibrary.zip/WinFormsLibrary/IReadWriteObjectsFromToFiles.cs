﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsLibrary
{
    public interface IReadWriteObjectsFromToFiles
    {
        // Метод для записи данных в файл.
        static void writeToFile() { }

        // Метод для чтения данных из файла.
        static void readFromFile() { }
    }
}
